function open_sidebar() {
    $('#overlay').css('display','block');
    $('#sidebar').css('display','block');
}
function cerrar_sidebar() {
    $('#overlay').css('display','none');
    $('#sidebar').css('display','none');
}